-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        5.7.26-log - MySQL Community Server (GPL)
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.1.0.6116
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

create database if not EXISTS `elemata`;
use `elemata`;
-- 导出 elemata 的数据库结构
DROP DATABASE IF EXISTS `elemata`;
CREATE DATABASE IF NOT EXISTS `elemata` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `elemata`;

-- 导出  表 elemata.links 结构
DROP TABLE IF EXISTS `links`;
CREATE TABLE IF NOT EXISTS `links` (
  `title` text NOT NULL,
  `link` text NOT NULL,
  `page_link` text NOT NULL,
  `menu` text NOT NULL,
  `order` int(11) NOT NULL,
  `active` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.links 的数据：~8 rows (大约)
DELETE FROM `links`;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` (`title`, `link`, `page_link`, `menu`, `order`, `active`, `id`) VALUES
	('Dashboard', '?action=dashboard', '', 'dashboard', 2, 'true', 1),
	('Pages', '?action=pages', '', 'dashboard', 0, 'true', 2),
	('Themes', '?action=themes', '', 'dashboard', 0, 'true', 3),
	('Plugins', '?action=plugins', '', 'dashboard', 0, 'true', 4),
	('Users', '?action=users', '', 'dashboard', 0, 'true', 5),
	('Settings', '?action=settings', '', 'dashboard', 0, 'true', 6),
	('Menus', '?action=menus', '', 'dashboard', 0, 'true', 7),
	('Media', '?action=media', '', 'dashboard', 1, 'true', 8);
/*!40000 ALTER TABLE `links` ENABLE KEYS */;

-- 导出  表 elemata.menus 结构
DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `name` text NOT NULL,
  `type` text NOT NULL,
  `location` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.menus 的数据：~1 rows (大约)
DELETE FROM `menus`;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` (`name`, `type`, `location`, `id`) VALUES
	('dashboard', 'normal', '0', 1);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;

-- 导出  表 elemata.notifications 结构
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `title` text NOT NULL,
  `value` text NOT NULL,
  `to` text NOT NULL,
  `from` text NOT NULL,
  `type` text NOT NULL,
  `group` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.notifications 的数据：~0 rows (大约)
DELETE FROM `notifications`;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;

-- 导出  表 elemata.options 结构
DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `name` text NOT NULL,
  `value` text NOT NULL,
  `active` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.options 的数据：~10 rows (大约)
DELETE FROM `options`;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` (`name`, `value`, `active`, `id`) VALUES
	('allow_reg', 'pass_req', '1', 1),
	('reg_pass', 'default', '', 2),
	('default_user_role', 'member', '1', 3),
	('auto_update', '', '0', 4),
	('allow_message', '', '1', 5),
	('current_theme', 'default', '1', 6),
	('admin_email', 'me@example.com', '1', 7),
	('elemata_link', '', '1', 8),
	('allow_actions', '', '1', 9),
	('timezone', 'America/New_York', '', 10);
/*!40000 ALTER TABLE `options` ENABLE KEYS */;

-- 导出  表 elemata.posts 结构
DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `title` text NOT NULL,
  `content` text NOT NULL,
  `page_type` text NOT NULL,
  `searchable` text NOT NULL,
  `color_scheme` text NOT NULL,
  `author` text NOT NULL,
  `date` text NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `locked` int(11) NOT NULL,
  `password` text NOT NULL,
  `modified` text NOT NULL,
  `mod_day` int(11) NOT NULL,
  `mod_month` int(11) NOT NULL,
  `mod_year` int(11) NOT NULL,
  `time` text NOT NULL,
  `menu_order` int(11) NOT NULL,
  `tags` text NOT NULL,
  `showmenu` text NOT NULL,
  `postinfo_visible` int(11) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_desc` text NOT NULL,
  `meta_robots` text NOT NULL,
  `meta_copyright` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.posts 的数据：~1 rows (大约)
DELETE FROM `posts`;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`title`, `content`, `page_type`, `searchable`, `color_scheme`, `author`, `date`, `day`, `month`, `year`, `locked`, `password`, `modified`, `mod_day`, `mod_month`, `mod_year`, `time`, `menu_order`, `tags`, `showmenu`, `postinfo_visible`, `meta_keywords`, `meta_desc`, `meta_robots`, `meta_copyright`, `id`) VALUES
	('Home', '<p>This is the homepage to the elemata theme. Feel free to edit this page if you would like to.</p>', 'page', '1', 'default', 'admin', 'January 1, 2012, 12:01 pm', 1, 1, 2012, 0, '0', '0', 0, 0, 0, '12:01PM', 1, 'home, elemata', '', 0, 'home', 'Elemata CMS 2.0', '1', 'Elemata CMS', 1);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;

-- 导出  表 elemata.settings 结构
DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `title` text NOT NULL,
  `footer_text` text NOT NULL,
  `header_text` text NOT NULL,
  `theme` text NOT NULL,
  `url` text NOT NULL,
  `favicon` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.settings 的数据：~1 rows (大约)
DELETE FROM `settings`;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`title`, `footer_text`, `header_text`, `theme`, `url`, `favicon`) VALUES
	('Elemata CMS', 'Elemata Content Management System', 'Elemata', 'revive', 'http://www.yoururl.com', '');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;

-- 导出  表 elemata.stats 结构
DROP TABLE IF EXISTS `stats`;
CREATE TABLE IF NOT EXISTS `stats` (
  `ip` text NOT NULL,
  `page` text NOT NULL,
  `date` text NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.stats 的数据：~0 rows (大约)
DELETE FROM `stats`;
/*!40000 ALTER TABLE `stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats` ENABLE KEYS */;

-- 导出  表 elemata.themes 结构
DROP TABLE IF EXISTS `themes`;
CREATE TABLE IF NOT EXISTS `themes` (
  `folder` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.themes 的数据：~1 rows (大约)
DELETE FROM `themes`;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` (`folder`, `id`) VALUES
	('revive', 1);
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;

-- 导出  表 elemata.users 结构
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `nickname` text NOT NULL,
  `type` text NOT NULL,
  `desc` text NOT NULL,
  `profile_active` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- 正在导出表  elemata.users 的数据：~1 rows (大约)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`username`, `password`, `email`, `nickname`, `type`, `desc`, `profile_active`, `id`) VALUES
	('admin', 'c4ca4238a0b923820dcc509a6f75849b', 'ryanweekly@gmail.com', 'Admin', 'admin', 'I am the admin of this website.', 'false', 1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
