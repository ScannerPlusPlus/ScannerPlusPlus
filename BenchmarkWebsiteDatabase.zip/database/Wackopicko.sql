-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        5.7.26-log - MySQL Community Server (GPL)
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.1.0.6116
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 导出 wacko 的数据库结构
CREATE DATABASE IF NOT EXISTS `wacko` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `wacko`;

-- 导出  表 wacko.admin 结构
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `password` char(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.admin 的数据：5 rows
DELETE FROM `admin`;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `login`, `password`) VALUES
	(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
	(2, 'adamd', 'c533607326f2b815a7c23701be52989dac8bdbb1'),
	(3, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
	(4, 'adam', '0ace61762d02afdf98f793d98c37edf696b675b2'),
	(5, 'bob', '42a9037223cdbfe0c49ef0032f0a1f3392af3fe3');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- 导出  表 wacko.admin_session 结构
CREATE TABLE IF NOT EXISTS `admin_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.admin_session 的数据：2 rows
DELETE FROM `admin_session`;
/*!40000 ALTER TABLE `admin_session` DISABLE KEYS */;
INSERT INTO `admin_session` (`id`, `admin_id`, `created_on`) VALUES
	(4, 1, '2021-02-04 11:26:24'),
	(3, 1, '2021-02-04 11:25:28');
/*!40000 ALTER TABLE `admin_session` ENABLE KEYS */;

-- 导出  表 wacko.cart 结构
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.cart 的数据：0 rows
DELETE FROM `cart`;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;

-- 导出  表 wacko.cart_coupons 结构
CREATE TABLE IF NOT EXISTS `cart_coupons` (
  `cart_id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  KEY `cart_id` (`cart_id`,`coupon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.cart_coupons 的数据：5 rows
DELETE FROM `cart_coupons`;
/*!40000 ALTER TABLE `cart_coupons` DISABLE KEYS */;
INSERT INTO `cart_coupons` (`cart_id`, `coupon_id`) VALUES
	(0, 0),
	(2, 1),
	(2, 1),
	(2, 1),
	(3, 1);
/*!40000 ALTER TABLE `cart_coupons` ENABLE KEYS */;

-- 导出  表 wacko.cart_items 结构
CREATE TABLE IF NOT EXISTS `cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `picture_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.cart_items 的数据：0 rows
DELETE FROM `cart_items`;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;

-- 导出  表 wacko.comments 结构
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL,
  `picture_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.comments 的数据：4 rows
DELETE FROM `comments`;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` (`id`, `text`, `user_id`, `picture_id`, `created_on`) VALUES
	(1, 'blah.	      ', 2, 3, '2009-01-12 19:05:45'),
	(2, 'That\\\'s an awesome butt...', 2, 2, '2009-01-12 19:26:21'),
	(3, '	      testing', 2, 5, '2009-01-21 15:32:44'),
	(4, 'This is my house, what do you guys think?', 2, 11, '2009-02-18 14:55:39');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;

-- 导出  表 wacko.comments_preview 结构
CREATE TABLE IF NOT EXISTS `comments_preview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL,
  `picture_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.comments_preview 的数据：11 rows
DELETE FROM `comments_preview`;
/*!40000 ALTER TABLE `comments_preview` DISABLE KEYS */;
INSERT INTO `comments_preview` (`id`, `text`, `user_id`, `picture_id`, `created_on`) VALUES
	(1, 'blah.	      ', 2, 3, '2009-01-12 19:01:49'),
	(2, 'blah.	      ', 2, 3, '2009-01-12 19:02:12'),
	(3, 'blah.	      ', 2, 3, '2009-01-12 19:02:52'),
	(4, 'blah.	      ', 2, 3, '2009-01-12 19:05:45'),
	(5, 'You suck. Should I use this?	      ', 2, 3, '2009-01-12 19:06:43'),
	(6, 'That\\\'s an awesome butt...', 2, 2, '2009-01-12 19:21:40'),
	(7, 'That\\\'s an awesome butt...', 2, 2, '2009-01-12 19:25:52'),
	(8, 'That\\\'s an awesome butt...', 2, 2, '2009-01-12 19:26:21'),
	(9, '	      test', 2, 5, '2009-01-21 15:06:05'),
	(11, '	      testing', 2, 5, '2009-01-21 15:32:44'),
	(12, 'This is my house, what do you guys think?', 2, 11, '2009-02-18 14:55:39');
/*!40000 ALTER TABLE `comments_preview` ENABLE KEYS */;

-- 导出  表 wacko.conflict_pictures 结构
CREATE TABLE IF NOT EXISTS `conflict_pictures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orig_filename` varchar(255) NOT NULL,
  `new_filename` varchar(255) NOT NULL,
  `new_tag` varchar(255) NOT NULL,
  `new_name` varchar(255) NOT NULL,
  `new_price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.conflict_pictures 的数据：0 rows
DELETE FROM `conflict_pictures`;
/*!40000 ALTER TABLE `conflict_pictures` DISABLE KEYS */;
/*!40000 ALTER TABLE `conflict_pictures` ENABLE KEYS */;

-- 导出  表 wacko.coupons 结构
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.coupons 的数据：2 rows
DELETE FROM `coupons`;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` (`id`, `code`, `discount`) VALUES
	(1, 'SUPERYOU21', 90),
	(2, 'SUPERYOU21', 90);
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;

-- 导出  表 wacko.guestbook 结构
CREATE TABLE IF NOT EXISTS `guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `created_on` datetime NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.guestbook 的数据：1 rows
DELETE FROM `guestbook`;
/*!40000 ALTER TABLE `guestbook` DISABLE KEYS */;
INSERT INTO `guestbook` (`id`, `name`, `comment`, `created_on`) VALUES
	(1, 'adam', 'Hi, I love your site!', '2008-12-02 19:32:53');
/*!40000 ALTER TABLE `guestbook` ENABLE KEYS */;

-- 导出  表 wacko.own 结构
CREATE TABLE IF NOT EXISTS `own` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `picture_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.own 的数据：3 rows
DELETE FROM `own`;
/*!40000 ALTER TABLE `own` DISABLE KEYS */;
INSERT INTO `own` (`id`, `user_id`, `picture_id`) VALUES
	(1, 2, 3),
	(2, 2, 2),
	(3, 11, 10);
/*!40000 ALTER TABLE `own` ENABLE KEYS */;

-- 导出  表 wacko.pictures 结构
CREATE TABLE IF NOT EXISTS `pictures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `tag` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `high_quality` varchar(250) NOT NULL,
  `created_on` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.pictures 的数据：9 rows
DELETE FROM `pictures`;
/*!40000 ALTER TABLE `pictures` DISABLE KEYS */;
INSERT INTO `pictures` (`id`, `title`, `width`, `height`, `tag`, `filename`, `price`, `high_quality`, `created_on`, `user_id`) VALUES
	(10, 'Awesome Flower Pic', 128, 128, 'flowers', 'flowers/flowers', 26, 'NjE4NDgwOQ==', '2009-02-18 14:54:56', 2),
	(9, 'The Boys - In costume', 128, 128, 'toga', 'toga/togasfs', 20, 'MTk1NDMxOQ==', '2009-02-18 14:54:13', 9),
	(8, 'Me and the Girls', 128, 128, 'toga', 'toga/togas', 10, 'MTc3Mjgx', '2009-02-18 14:53:48', 9),
	(7, 'My Dog', 128, 128, 'doggie', 'doggie/Dog.jpg', 15, 'OTA5MjA1NA==', '2009-02-18 14:50:30', 1),
	(11, 'My House!', 128, 128, 'house', 'house/My_House', 16, 'ODExNzIzOQ==', '2009-02-18 14:55:20', 2),
	(12, 'Beautiful Waterfall', 128, 128, 'waterfall', 'waterfall/Waterfall', 10, 'ODQ4OTkx', '2009-02-18 14:56:47', 10),
	(13, 'Our House', 128, 128, 'house', 'house/our_house', 30, 'OTE4MzM1Mw==', '2009-02-18 14:57:18', 10),
	(14, 'The house I share', 128, 128, 'house', 'house/hodjjgld', 20, 'MzM4OTU3MA==', '2009-02-18 14:57:58', 11),
	(15, 'This grows outside my house', 128, 128, 'flowers', 'flowers/flweofoee', 40, 'ODcxNDAyNA==', '2009-02-18 14:58:33', 11);
/*!40000 ALTER TABLE `pictures` ENABLE KEYS */;

-- 导出  表 wacko.users 结构
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `password` char(40) NOT NULL,
  `salt` char(4) NOT NULL,
  `tradebux` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `last_login_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- 正在导出表  wacko.users 的数据：10 rows
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `login`, `firstname`, `lastname`, `password`, `salt`, `tradebux`, `created_on`, `last_login_on`) VALUES
	(1, 'Sample User', 'Sample', 'User', '3e912f8fc814831804d735dc2fcbc3cfa75c28e3', 'NjM2', 130, '2009-01-05 14:29:00', '2009-02-18 14:50:00'),
	(2, 'bob', 'I Am Bob', 'Gilbert', 'abd09072e674720d87ddd27122f67eedbc4b0d08', 'Mjkx', 96, '2009-01-05 14:51:05', '2009-02-18 14:54:26'),
	(4, 'scanner1', 'Scanner', '1', 'af256af3d4fda990dbe546daa04e5c75eae356ea', 'ODUy', 100, '2009-02-18 14:46:21', '2009-02-18 14:46:21'),
	(5, 'scanner2', 'Scanner', '2', 'f9335d39b2b78018c2b8affa7fc7b0917a3300a7', 'MzI5', 100, '2009-02-18 14:46:34', '2009-02-18 14:46:34'),
	(6, 'scanner3', 'Scanner', '3', '43754746b4043c852864bb321e4f2648d1421c18', 'Nzk3', 100, '2009-02-18 14:46:51', '2009-02-18 14:46:51'),
	(7, 'scanner4', 'Number', '4', 'e514a672396679528c766a92a857eac4b22bc667', 'NjEx', 100, '2009-02-18 14:47:04', '2009-02-18 14:47:04'),
	(8, 'scanner5', 'Number', '5', 'f38ae9b0b6b1ad2a2a2721841c0cc89b31e044cb', 'NTQw', 100, '2009-02-18 14:47:18', '2009-02-18 14:47:18'),
	(9, 'wanda', 'Wanda', 'Granat', '4e4465300b14b314384a6375a837f0532822d3c8', 'Nzcz', 100, '2009-02-18 14:53:23', '2009-02-18 14:53:23'),
	(10, 'calvinwatters', 'Calvin', 'Watters', '81418ed6e9bd15076d2f43e17b9f5a27c7e55ef7', 'Nzc5', 100, '2009-02-18 14:56:11', '2009-02-18 14:56:11'),
	(11, 'bryce', 'Bryce', 'Boe', '478fb0b83851b3d16ffc5a2554a4d616f1235156', 'NjY3', 74, '2009-02-18 14:57:36', '2009-02-18 14:57:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
