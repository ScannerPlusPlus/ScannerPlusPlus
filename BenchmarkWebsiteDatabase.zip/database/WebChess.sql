create database if not exists webchess;
use `webchess`;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table games
# ------------------------------------------------------------

DROP TABLE IF EXISTS `games`;

CREATE TABLE `games` (
  `gameID` smallint(6) NOT NULL AUTO_INCREMENT,
  `whitePlayer` mediumint(9) NOT NULL,
  `blackPlayer` mediumint(9) NOT NULL,
  `gameMessage` enum('playerInvited','inviteDeclined','draw','playerResigned','checkMate') DEFAULT NULL,
  `messageFrom` enum('black','white') DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `lastMove` datetime NOT NULL,
  PRIMARY KEY (`gameID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `history`;

CREATE TABLE `history` (
  `timeOfMove` datetime NOT NULL,
  `gameID` smallint(6) NOT NULL,
  `curPiece` enum('pawn','bishop','knight','rook','queen','king') NOT NULL,
  `curColor` enum('white','black') NOT NULL,
  `fromRow` smallint(6) NOT NULL,
  `fromCol` smallint(6) NOT NULL,
  `toRow` smallint(6) NOT NULL,
  `toCol` smallint(6) NOT NULL,
  `replaced` enum('pawn','bishop','knight','rook','queen','king') DEFAULT NULL,
  `promotedTo` enum('pawn','bishop','knight','rook','queen','king') DEFAULT NULL,
  `isInCheck` tinyint(1) NOT NULL,
  PRIMARY KEY (`timeOfMove`,`gameID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table messages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `msgID` int(11) NOT NULL AUTO_INCREMENT,
  `gameID` smallint(6) NOT NULL,
  `msgType` enum('undo','draw') NOT NULL,
  `msgStatus` enum('request','approved','denied') NOT NULL,
  `destination` enum('black','white') NOT NULL,
  PRIMARY KEY (`msgID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table pieces
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pieces`;

CREATE TABLE `pieces` (
  `gameID` smallint(6) NOT NULL,
  `color` enum('white','black') NOT NULL,
  `piece` enum('pawn','rook','knight','bishop','queen','king') NOT NULL,
  `col` smallint(6) NOT NULL,
  `row` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table players
# ------------------------------------------------------------

DROP TABLE IF EXISTS `players`;

CREATE TABLE `players` (
  `playerID` int(11) NOT NULL AUTO_INCREMENT,
  `password` char(16) NOT NULL,
  `firstName` char(20) NOT NULL,
  `lastName` char(20) NOT NULL,
  `nick` char(20) NOT NULL,
  PRIMARY KEY (`playerID`),
  UNIQUE KEY `nick` (`nick`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;

INSERT INTO `players` (`playerID`, `password`, `firstName`, `lastName`, `nick`)
VALUES
	(1,'aurora','aurora','aurora','aurora');

/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table preferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `preferences`;

CREATE TABLE `preferences` (
  `playerID` int(11) NOT NULL,
  `preference` char(20) NOT NULL,
  `value` char(50) DEFAULT NULL,
  PRIMARY KEY (`playerID`,`preference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;

INSERT INTO `preferences` (`playerID`, `preference`, `value`)
VALUES
	(1,'autoreload','5'),
	(1,'emailnotification',''),
	(1,'history','pgn'),
	(1,'theme','beholder');

/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
